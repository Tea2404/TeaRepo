-- Query total sales per product category from the fact table.

select dp.product_category_name, round(sum(f.total_price), 2) as total_sales
from  fact_order_items f , dim_products  dp 
where f.product_id = dp.product_id
group by dp.product_category_name
order by total_sales desc;


--Query the average delivery time per seller from the fact table

select ds.seller_id, avg(datediff(day, dd.order_purchase_timestamp, dd.order_delivered_customer_date)) as average_delivery_time
from   dim_date dd, fact_order_items  f, dim_sellers ds 
where 
dd.order_id = f.order_id  
and f.seller_id = ds.seller_id
and  dd.order_purchase_timestamp is not null
and dd.order_delivered_customer_date is not null
group by ds.seller_id
order by average_delivery_time;

-- Query the number of orders from each state from the customer dimension.

select dc.customer_state, count(distinct f.order_id) as number_of_orders
from  dim_customers dc, fact_order_items f 
where dc.customer_id = f.customer_id
group by dc.customer_state
order by number_of_orders desc;

