### Connect Python to SQL Server

import pyodbc


server = 'localhost'
database = 'OlistDataset'
username = 'sa'
password = 'pokita'

connection_string = f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};UID={username};PWD={password}'

try:
    connection = pyodbc.connect(connection_string)
    print("Connection successful!")
    
except pyodbc.Error as e:
    print(f"Error: {e}")
    
finally:
    if 'connection' in locals() and connection:
        connection.close()

### Load all CSV files into a Jupyter Notebook using Pandas.

import pandas as pd

base_path = r'C:\Users\use\Documents\Python Scripts\archive'

orders = pd.read_csv(f'{base_path}\\olist_orders_dataset.csv')
customers = pd.read_csv(f'{base_path}\\olist_customers_dataset.csv')
products = pd.read_csv(f'{base_path}\\olist_products_dataset.csv')
sellers = pd.read_csv(f'{base_path}\\olist_sellers_dataset.csv')
order_items = pd.read_csv(f'{base_path}\\olist_order_items_dataset.csv')
order_payments = pd.read_csv(f'{base_path}\\olist_order_payments_dataset.csv')
order_reviews = pd.read_csv(f'{base_path}\\olist_order_reviews_dataset.csv')

### Req #1: Clean the datasets

orders.dropna(subset=['order_id'], inplace=True)
customers.dropna(subset=['customer_id'], inplace=True)
products.dropna(subset=['product_id'], inplace=True)
sellers[['seller_zip_code_prefix']] = sellers[['seller_zip_code_prefix']].fillna(value="Unknown")
order_items.dropna(inplace=True)
order_payments.dropna(inplace=True)
order_reviews[['review_comment_title', 'review_comment_message']] = order_reviews[['review_comment_title', 'review_comment_message']].fillna(value="None")


orders.drop_duplicates(inplace=True)
customers.drop_duplicates(inplace=True)
products.drop_duplicates(inplace=True)
sellers.drop_duplicates(inplace=True)
order_items.drop_duplicates(inplace=True)
order_payments.drop_duplicates(inplace=True)
order_reviews.drop_duplicates(inplace=True)

### Req #2: Create Calculated Columns


# converting to datetime
orders['order_purchase_timestamp'] = pd.to_datetime(orders['order_purchase_timestamp'])
orders['order_delivered_customer_date'] = pd.to_datetime(orders['order_delivered_customer_date'])
orders['order_approved_at'] = pd.to_datetime(orders['order_approved_at'])
orders['order_estimated_delivery_date'] = pd.to_datetime(orders['order_estimated_delivery_date'])

# merge of tables needed for calculation (order_items, orders, order_payments)
merged_df = pd.merge(order_items, orders, on='order_id', how='left')
merged_df = pd.merge(merged_df, order_payments[['order_id', 'payment_installments']], on='order_id', how='left')

# total price
merged_df['total_price'] = merged_df['price'] + merged_df['freight_value']

# delivery time
merged_df['delivery_time'] = (merged_df['order_delivered_customer_date'] - merged_df['order_purchase_timestamp']).dt.days

# payment count
merged_df['payment_installments'] = merged_df['payment_installments'].fillna(0)
payment_count = merged_df.groupby('order_id')['payment_installments'].transform('sum')
merged_df['payment_count'] = payment_count

# profit margit
merged_df['profit_margin'] = merged_df['price'] - merged_df['freight_value']
merged_df['payment_count'] = payment_count


# updated dataframe
merged_df[['order_id', 'total_price', 'delivery_time', 'payment_count', 'profit_margin']].head()



### Req #3: Use Window Functions Over Partitions (Pandas)

# merge order_items and orders
merged_df = pd.merge(order_items, orders[['order_id', 'customer_id', 'order_purchase_timestamp', 'order_delivered_customer_date']], on='order_id', how='left')

# merge with products
merged_df = pd.merge(merged_df, products[['product_id', 'product_category_name']], on='product_id', how='left')

# total sales per customer
merged_df['total_sales_per_customer'] = merged_df.groupby('customer_id')['price'].cumsum()

# average delivery time per product category
merged_df['delivery_time'] = (merged_df['order_delivered_customer_date'] - merged_df['order_purchase_timestamp']).dt.days
merged_df['average_delivery_time_per_category'] = merged_df.groupby('product_category_name')['delivery_time'].rolling(window=3, min_periods=1).mean().reset_index(0, drop=True)
  
# updated dataframe
merged_df[['customer_id', 'product_category_name', 'price', 'total_sales_per_customer', 'delivery_time', 'average_delivery_time_per_category']].head()

### Req #4: Saving Processed Data to SQL Server (Fact & Dimension Tables)

import pandas as pd
from sqlalchemy import create_engine
import pyodbc

server = 'localhost'
database = 'OlistDataset'
username = 'sa'
password = 'pokita'

connection_string = f'mssql+pyodbc://{username}:{password}@{server}/{database}?driver=ODBC+Driver+17+for+SQL+Server'

try:
    engine = create_engine(connection_string)
    connection = engine.connect()
    print("Connection successful!")
    connection.close()
except Exception as e:
    print(f"Connection failed: {e}")
	
	
	merged_df['total_price'] = merged_df['price'] + merged_df['freight_value']
merged_df['payment_count'] = payment_count
merged_df['profit_margin'] = merged_df['price'] - merged_df['freight_value']

# creation of fact table
fact_table = merged_df[['customer_id','order_id', 'product_id', 'seller_id','price', 'freight_value', 
                        'total_price', 'delivery_time', 'payment_count', 'profit_margin']]

# creation of dimension table for customers
dim_customers = customers[['customer_id', 'customer_zip_code_prefix', 'customer_city', 'customer_state']]

# creation of dimension table for products
dim_products = products[['product_id', 'product_category_name', 'product_name_lenght', 'product_description_lenght',
                         'product_photos_qty', 'product_weight_g', 
                         'product_length_cm', 'product_height_cm', 'product_width_cm']]

# creation of dimension table for sellers
dim_sellers = sellers[['seller_id', 'seller_zip_code_prefix', 'seller_city', 'seller_state']]

# creation of dimension table for dates

dim_date = pd.merge(
    orders[['order_id', 'order_purchase_timestamp', 'order_delivered_customer_date']],
    merged_df[['order_id', 'seller_id']], 
    on='order_id',
    how='left'
)[['order_id', 'seller_id', 'order_purchase_timestamp', 'order_delivered_customer_date']]


# save the tables to SQL Server
fact_table.to_sql('fact_order_items', engine, if_exists='replace', index=False)
dim_customers.to_sql('dim_customers', engine, if_exists='replace', index=False)
dim_products.to_sql('dim_products', engine, if_exists='replace', index=False)
dim_sellers.to_sql('dim_sellers', engine, if_exists='replace', index=False)
dim_date.to_sql('dim_date', engine, if_exists='replace', index=False)

print("Data has been successfully saved to SQL Server!")



